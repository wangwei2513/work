var menuData = [{
	name : "党建高泽",
	imageUrl : "images/pic1_01.jpg",
	linkUrl : "./index.htm",
	portalPos : 0
},{
	name : "仙境高泽",
	imageUrl : "images/pic1_03.jpg",
	linkUrl : "./index.htm",
	portalPos : 4
},{
	name : "平安高泽",
	imageUrl : "images/pic1_05.jpg",
	linkUrl : "./index.htm",
	portalPos : 1
},{
	name : "和谐高泽",
	imageUrl : "images/pic1_07.jpg",
	linkUrl : "./index.htm",
	portalPos : 5
},{
	name : "激情高泽",
	imageUrl : "images/pic1_02.jpg",
	linkUrl : "./index.htm",
	portalPos : 2
},{
	name : "活力高泽",
	imageUrl : "images/pic1_04.jpg",
	linkUrl : "./index.htm",
	portalPos : 3
},{
	name : "阳光高泽",
	imageUrl : "images/pic1_06.jpg",
	linkUrl : "./index.htm",
	portalPos : 6
}];

var videoData = {
	videoUrl : "",
	pos : {
		width:460,
		height:256,
		left:411,
		top:170
	}	
}