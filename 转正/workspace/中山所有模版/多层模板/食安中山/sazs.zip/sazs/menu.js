[
    {
        "blurImageUrl": "",
        "enName": "sub_nameList",
        "entryWord": "",
        "focusImageUrl": "images/top_01.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "红黑榜",
        "newAdd": 4,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "sub_safety",
        "entryWord": "",
        "focusImageUrl": "images/top_02.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "安全小常识",
        "newAdd": 4,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "sub_supervise",
        "entryWord": "",
        "focusImageUrl": "images/top_03.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "监管一线",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "sub_activity",
        "entryWord": "",
        "focusImageUrl": "images/top_04.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "福利进行时",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "sub_contact",
        "entryWord": "",
        "focusImageUrl": "images/top_05.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "联系我们",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_01.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_02.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_04.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_07.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 4,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_05.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_06.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_03.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_01.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "square_iframe_monitor",
        "entryWord": "",
        "focusImageUrl": "images/pic_02.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_04.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 4,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "",
        "entryWord": "",
        "focusImageUrl": "images/pic_07.png",
        "isManaged": "managed",
        "listType": "list",
        "name": "",
        "newAdd": 0,
        "nodePath": ""
    }
]