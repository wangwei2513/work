{
	"blurImageUrl": "",
	"clickable": 1,
	"enName": "sub_rblist",
	"entryWord": "",
	"focusImageUrl": "",
	"isManaged": "managed",
	"linkUrl": "",
	"listType": "list",
	"name": "��ڰ�",
	"navigator": "ʳ����ɽ>��ڰ�>��ڰ�",
	"newAdd": 1,
	"nodePath": "sazs/sub_list_01/sub_rblist"
}