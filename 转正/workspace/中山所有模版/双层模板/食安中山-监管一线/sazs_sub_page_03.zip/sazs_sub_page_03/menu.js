[
    {
        "blurImageUrl": "",
        "enName": "sub_city",
        "entryWord": "",
        "focusImageUrl": "",
        "isManaged": "managed",
        "listType": "list",
        "name": "市局动态",
        "newAdd": 4,
        "nodePath": ""
    },
    {
        "blurImageUrl": "",
        "enName": "sub_basic",
        "entryWord": "",
        "focusImageUrl": "",
        "isManaged": "managed",
        "listType": "list",
        "name": "基层动态",
        "newAdd": 4,
        "nodePath": ""
    }
]