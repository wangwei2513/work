[
    {
        "blurImageUrl": "",
        "enName": "sub_act",
        "entryWord": "",
        "focusImageUrl": "",
        "isManaged": "managed",
        "listType": "list",
        "name": "福利进行时",
        "newAdd": 4,
        "nodePath": ""
    }
]