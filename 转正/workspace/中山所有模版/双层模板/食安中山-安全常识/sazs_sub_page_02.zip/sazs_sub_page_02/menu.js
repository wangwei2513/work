[
    {
        "blurImageUrl": "",
        "enName": "sub_scikn",
        "entryWord": "",
        "focusImageUrl": "",
        "isManaged": "managed",
        "listType": "list",
        "name": "科普知识",
        "newAdd": 4,
        "nodePath": ""
    }
]