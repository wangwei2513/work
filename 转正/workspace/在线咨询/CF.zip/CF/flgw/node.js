{
    "blurImageUrl": "",
    "clickable": 1,
    "enName": "flgw",
    "entryWord": "",
    "focusImageUrl": "images/logo.png",
    "isManaged": "managed",
    "linkUrl": "",
    "listType": "",
    "name": "法律顾问",
    "navigator": "",
    "newAdd": 0,
    "nodePath": "cffz/flgw"
}