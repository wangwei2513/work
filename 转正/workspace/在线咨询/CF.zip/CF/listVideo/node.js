{
    "blurImageUrl": "",
    "clickable": 1,
    "enName": "fzjt",
    "entryWord": "",
    "focusImageUrl": "images/logo.png",
    "isManaged": "managed",
    "linkUrl": "",
    "listType": "",
    "name": "法制讲堂",
    "navigator": "",
    "newAdd": 0,
    "nodePath": "cffz/fzjt"
}