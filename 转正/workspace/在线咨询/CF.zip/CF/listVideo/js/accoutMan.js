/****登陆homed的方式: 0:mac账号 1:盒子序列号 2:ca卡号****/
var cardSerialNum = 2; 
var isIP = 1;	// 0：ip，1：域名
var domain = ["http://10.71.62.111:12690/","http://access.homed.me/"][isIP];
var userlist = domain+"account/user/get_list?deviceno={1}&devicetype={2}&pageidx={3}&pagenum={4}";
var userlogin = domain+"account/login?deviceno={1}&devicetype={2}&accounttype={3}&account={4}&accesstoken={5}&";
var registeruser = domain+"account/user/register?username={1}&type={2}&accounttype={3}&nickname={4}&iconid=1&pwd={5}&deviceno={6}&devicetype={7}"
 

/*
*账号的查询，注册和登录处理
*/
//var accoutUrl = "http://access.ybgd96655.net";
var accountAjaxObj = null;//账户相关操作ajax对象
var loginCardId = "";//账户的ca卡号
var callBackStr = "";//登录成功后的回调
var accessToken = "";
/**判断是否登录过或者ca卡号有变化**/
function checkAccoutLogin(__callBackStr){	
	if(typeof __callBackStr != "undefined") callBackStr = __callBackStr;
	else callBackStr = "";
	loginCardId = getCaNo(); 
	if(typeof gotoPortal!="undefined"){
		accessToken = iPanel.eventFrame.access_token;
	}else{
		accessToken = getGlobalVar("accessToken");
	}
	iDebug("[checkAccoutLogin]accessToken="+accessToken + ";loginCardId="+loginCardId);
	if(typeof(accessToken)=="undefinded" || accessToken == "" || accessToken == null){
		getUserListInfo();
	}else{
		var tmpCardId = getGlobalVar("loginDeviceNo");
		if(loginCardId && (loginCardId != tmpCardId)){//卡号变化后，也重新登录
			delGlobalVar("loginDeviceNo");
			delGlobalVar("accessToken");
			getUserListInfo();	
		} else {
			loginCallBack(accessToken);
		}
	}	
}

/**获取username(用户号)**/
function getUserListInfo(){
	if(accountAjaxObj == null) {
		accountAjaxObj = new ajaxClass();
	} else {
		accountAjaxObj.requestAbort();
	}
	var devicetype = (cardSerialNum==0||cardSerialNum==1)?1:2;
	accountAjaxObj.url = userlist.replace("{1}",loginCardId).replace("{2}",devicetype).replace("{3}","1").replace("{4}","10");
	iDebug("[getUserListInfo]url="+ accountAjaxObj.url);
	accountAjaxObj.successCallback = function(xhr) {
		var responseText = xhr.responseText;
		eval("var tpmObj="+responseText);
		iDebug("[getUserListInfo]responseText="+ responseText);
		if(tpmObj.user_list && tpmObj.user_list.length > 0){
			if(devicetype == 1){
				accoutLogin(tpmObj.user_list[0].user_name);
			}else{
				accoutLogin(tpmObj.user_list[0].user_id,1);	
			}
		}else{
			registerUser();	
		}
	};
	accountAjaxObj.failureCallback = function(xhr){
		
	};
	accountAjaxObj.requestData();	
}

/**账号注册**/
function registerUser(){
	if(accountAjaxObj == null) {
		accountAjaxObj = new ajaxClass();
	} else {
		accountAjaxObj.requestAbort();
	}
	var type = (cardSerialNum==0||cardSerialNum==1)?1:2;
	var accounttype = (cardSerialNum==0||cardSerialNum==1)?2:1;
	var devicetype = (cardSerialNum==0||cardSerialNum==1)?0:2;
	accountAjaxObj.url = registeruser.replace("{1}",loginCardId).replace("{2}",type).replace("{3}",accounttype).replace("{4}",loginCardId).replace("{5}","111111").replace("{6}",loginCardId).replace("{7}",devicetype);
	iDebug("[registerUser]url="+ accountAjaxObj.url);
	accountAjaxObj.successCallback = function(xhr) {
		var responseText = xhr.responseText;
		iDebug("[registerUser]responseText="+ responseText);
		eval("var tpmObj="+responseText);
		if(tpmObj.user_id){
			accoutLogin(tpmObj.user_id,1);	
		}
	};
	accountAjaxObj.failureCallback = function(xhr){
		
	};
	accountAjaxObj.requestData();	
}

/**登录，__type:1 userId登录，其他为username登录**/
function accoutLogin(__account,__type){
	var accounttype = 2;
	if(__type == 1) accounttype = 1;
	if(accountAjaxObj == null) {
		accountAjaxObj = new ajaxClass();
	} else {
		accountAjaxObj.requestAbort();
	}	
	var devicetype = (cardSerialNum==0||cardSerialNum==1)?1:2;
	accountAjaxObj.url = userlogin.replace("{1}",loginCardId).replace("{2}",devicetype).replace("{3}",accounttype).replace("{4}",__account).replace("{5}","");
	iDebug("[accoutLogin]url="+ accountAjaxObj.url);
	accountAjaxObj.successCallback = function(xhr) {
		var responseText = xhr.responseText;
		iDebug("[accoutLogin]responseText="+ responseText);
		eval("var tpmObj="+responseText);
		accessToken = tpmObj.access_token;
		loginCallBack(accessToken);
	};
	accountAjaxObj.failureCallback = function(xhr){
		
	};
	accountAjaxObj.requestData();
}

/**登录成功后的操作**/
function loginCallBack(__accessToken){
	iDebug("[loginCallBack]accessToken="+ __accessToken);
	setGlobalVar("accessToken",__accessToken);
	setGlobalVar("loginDeviceNo",loginCardId);
	if(typeof callBackStr != "undefined"){
		eval(callBackStr+"()");
	}
}

function getCaNo(){
	var navigatorFlag = getBrowserType();
	var cardId = "";
	iDebug("accountMan.js---getCaNo--navigatorFlag="+navigatorFlag);
	if(navigatorFlag == "Inspur"){//浪潮
		cardId = iSTB.settings.get("sys:ca0:cardnumber");
		cardId = cardId.toUpperCase();
	}else if(navigatorFlag == "iPanel" || navigatorFlag == "advance"){
		cardId = [network.ethernets[0].MACAddress,hardware.smartCard.serialNumber,CA.card.cardId][cardSerialNum]; //使用MAC地址登陆
	}else if(navigatorFlag == "android"){
		var json = eval(DRMPlayer.getNetworkInfo());
		iDebug("accountMan.js---getCaNo--json="+json);
		cardId = [json[0].mac,"",""][cardSerialNum];
	}else{//00-27-1a-00-66-06
		cardId = ["00-7E-56-4B-7D-07","1234567890","8538002343236584"][cardSerialNum];
	}
	return cardId;
}

/********浏览器类型判断**********/
function getBrowserType(){	
	var ua = navigator.userAgent.toLowerCase();
	//iDebug(">>>zhaoql--getBrowserType--ua="+ua);
	if(/ipanel/.test(ua)){
		if(/advance/.test(ua))return "advance";//advance
		return "iPanel";//3.0
	}
	return /enrich/.test(ua) ? 'EVM'
		: /wobox/.test(ua) ? 'Inspur'
		: window.ActiveXObject ? 'IE'
		: document.getBoxObjectFor || /firefox/.test(ua) ? 'FireFox'
		: window.openDatabase && !/chrome/.test(ua) ? 'Safari'
		: /opr/.test(ua) ? 'Opera'
		:/android/.test(ua)?'android'
		: window.MessageEvent && !document.getBoxObjectFor ? 'Chrome'
		: '';
}