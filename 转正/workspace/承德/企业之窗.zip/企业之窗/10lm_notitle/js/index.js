var title = "";
var marqueeText = "�е�����С��ҵ�ּ��ơ�"; //��������
var backUrl = "../index.htm";


var focusInfo = [ 
	{"up":-1,"right":1,"down":5,"left":-1,posInfo:{"left":68,"top":112,"width":686,"height":328},"focusImage":"images/js-tu1.png"},//0
	{"up":-1,"right":2,"down":3,"left":0,posInfo:{"left":758,"top":112,"width":225,"height":161},"focusImage":"images/js-tu2.png"},//1
	{"up":-1,"right":-1,"down":4,"left":1,posInfo:{"left":987,"top":112,"width":225,"height":161},"focusImage":"images/js-tu3.png"},//2
	{"up":1,"right":4,"down":8,"left":0,posInfo:{"left":758,"top":278,"width":225,"height":161},"focusImage":"images/js-tu4.png"},//3
	{"up":2,"right":-1,"down":9,"left":3,posInfo:{"left":987,"top":278,"width":225,"height":161},"focusImage":"images/js-tu5.png"},//4
	{"up":0,"right":6,"down":-1,"left":-1,posInfo:{"left":68,"top":443,"width":225,"height":161},"focusImage":"images/js-tu6.png"},//5
	{"up":0,"right":7,"down":-1,"left":5,posInfo:{"left":298,"top":443,"width":225,"height":161},"focusImage":"images/js-tu7.png"},//6
	{"up":0,"right":8,"down":-1,"left":6,posInfo:{"left":528,"top":443,"width":225,"height":161},"focusImage":"images/js-tu8.png"},//7
	{"up":3,"right":9,"down":-1,"left":7,posInfo:{"left":758,"top":443,"width":225,"height":161},"focusImage":"images/js-tu9.png"},//8
	{"up":4,"right":-1,"down":-1,"left":8,posInfo:{"left":987,"top":443,"width":225,"height":161},"focusImage":"images/js-tu10.png"}//0
];