{
    "data": [
        {
            "Name": "聘请导游",
            "Url": "../hotel/myHotel_introduction.htm",
            "NameEn": "jdjs",
            "ID": 195,
            "Icon": "http://10.4.8.52:8080/ContentWS/res/Image-0-195-pricolumnicon.png"
        },
        {
            "Name": "景点购票",
            "Url": "../hotel/myHotel_food.htm",
            "NameEn": "ddpl",
            "ID": 255,
            "Icon": "http://10.4.8.52:8080/ContentWS/res/Image-0-255-pricolumnicon.png"
        },
        {
            "Name": "旅游报名",
            "Url": "../hotel/hotel_roomFacility.htm",
            "NameEn": "jsfw",
            "ID": 254,
            "Icon": "http://10.4.8.52:8080/ContentWS/res/Image-0-254-pricolumnicon.png"
        },
        {
            "Name": "机票预订",
            "Url": "../hotel/myHotel_lifeShop.htm",
            "NameEn": "ddwh",
            "ID": 253,
            "Icon": "http://10.4.8.52:8080/ContentWS/res/Image-0-253-pricolumnicon.png"
        }
    ]
}