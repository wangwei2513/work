{
    "folder": "../res/json/",
    "filename": "json_39_20171128135550.txt",
    "uniqueAttr": 9,
    "uniqueCont": 27,
    "thinfo": [{
        "attribute6": "%E7%94%B5%E5%99%A8%E7%B1%BB",
        "attribute7": "%E9%A3%9F%E5%93%81%E7%B1%BB",
        "attribute8": "%E5%B7%A5%E5%85%B7%E7%B1%BB",
        "attribute9": "%E7%94%9F%E6%B4%BB%E7%B1%BB"
    }],
    "info": [{
            "mID": "5",
            "attribute6": "%E6%95%B0%E6%8D%AE%E7%BA%BF",
            "attribute7": "%E6%B0%B4%E6%9E%9C%E7%9B%98",
            "attribute8": "%E6%8C%87%E7%94%B2%E5%88%80",
            "attribute9": "%E5%87%B3%E5%AD%90",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "6",
            "attribute6": "%E7%BD%91%E7%BA%BF++",
            "attribute7": "%E4%BF%9D%E6%B8%A9%E9%A5%AD%E7%9B%92",
            "attribute8": "%E7%93%B6%E8%B5%B7%E5%AD%90",
            "attribute9": "%E6%A1%8C%E5%AD%90",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "7",
            "attribute6": "%E7%94%B5%E8%9A%8A%E9%A6%99+",
            "attribute7": "%E8%8F%9C%E6%9D%BF",
            "attribute8": "%E8%9E%BA%E4%B8%9D%E5%88%80",
            "attribute9": "%E8%8D%9E%E9%BA%A6%E7%9A%AE%E6%9E%95%E5%A4%B4",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "8",
            "attribute6": "%E7%94%B5%E6%9A%96%E6%B0%94+",
            "attribute7": "%E4%B8%80%E6%AC%A1%E6%80%A7%E6%96%B9%E4%BE%BF%E7%AD%B7+%E7%89%99%E7%AD%BE",
            "attribute8": "%E9%92%B3%E5%AD%90+",
            "attribute9": "%E5%A4%8F%E5%87%89%E8%A2%AB",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "9",
            "attribute6": "%E7%86%A8%E7%83%AB%E6%9C%BA",
            "attribute7": "%E9%A4%90%E5%85%B7%EF%BC%88%E7%AD%B7%E5%AD%90+%E5%B0%8F%E7%A2%97+%E7%A2%9F%E5%AD%90%EF%BC%89",
            "attribute8": "%E5%89%AA%E5%88%80",
            "attribute9": "%E7%84%97%E5%A4%B4%E4%B8%93%E7%94%A8%E6%9E%95%E8%A2%8B",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "10",
            "attribute6": "%E7%94%B5%E6%BA%90%E5%BB%B6%E9%95%BF%E7%BA%BF",
            "attribute7": "",
            "attribute8": "%E6%B0%B4%E6%9E%9C%E5%88%80",
            "attribute9": "%E5%A9%B4%E5%84%BF%E5%BA%8A",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "11",
            "attribute6": "%E6%8F%92%E6%8E%92",
            "attribute7": "",
            "attribute8": "",
            "attribute9": "",
            "subth": [],
            "submenu": []
        }
    ]
}