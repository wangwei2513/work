
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",
			"attribute2": "sort",
            "attribute3": "serviceName",
            "attribute4": "serviceNameEn",
            "attribute5": "serviceTime",
            "attribute6": "price"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "1",
            "attribute2": "0",
            "attribute3": "中医推拿",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "59元"
        },{
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "面部SPA",
            "attribute4": "type2",
            "attribute5": "90分钟",
            "attribute6": "109元"
        },{
            "mID": "3",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "针灸拔罐",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "109元"
        },{
            "mID": "4",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "泰式按摩",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "109元"
        },{
            "mID": "5",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "精油香薰",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "109元"
        },{
            "mID": "6",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "全身SPA",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "109元"
        }

    ]
}