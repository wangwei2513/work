// 优惠活动
{
    "folder": "../res/json/",
    "filename": "json_p_20170320143224.txt",
    "uniqueAttr": 12,
    "uniqueCont": 1,
    "thinfo": [
        {
            "attribute1": "id",
            "attribute2": "sort",
            "attribute3": "name",
            "attribute4": "nameDetail",
            "attribute5": "intro",
            "attribute6": "clause"
        }
    ],
    "info": [
        {
            "mID": "1",
            "attribute1": "1",
            "attribute2": "1",
            "attribute3": "特赏礼遇",
            "attribute4": "轻松享受额外超值优惠",
            "attribute5": "使用“特赏礼遇”价格预订房间，可以享受客房优惠，免费宽带上网服务，延迟退房至下午4时，更额外免费享受以下一项附加服务：<br/>· 单程接机服务（机场-酒店）<br/>· 单程送机服务（酒店-机场）<br/>· 每日自助午餐或自助晚餐一份",
            "attribute6": "条款与细则:<br/>1.至少连续入住两晚。<br/>2.至少连续入住两晚。<br/>3.至少连续入住两晚。",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "1",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "“提前预订”优惠",
            "attribute4": "使用“提前预订”优惠价提前将房间预订好，并能节省住宿费用",
            "attribute5": "提前预定房间，可以享受客房优惠，免费宽带上网服务，延迟退房至下午4时，更额外免费享受以下一项附加服务：<br/>· 单程接机服务（机场-酒店）<br/>· 单程送机服务（酒店-机场）<br/>· 每日自助午餐或自助晚餐一份",
            "attribute6": "条款与细则:<br/>1.至少连续入住两晚。",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "1",
            "attribute1": "3",
            "attribute2": "1",
            "attribute3": "豪华水疗套餐",
            "attribute4": "告别压力，让香格里拉水疗护理及缤纷入住礼遇带您舒缓身心",
            "attribute5": "豪华水疗套餐，可以享受客房优惠，免费宽带上网服务，延迟退房至下午4时，更额外免费享受以下一项附加服务：<br/>· 单程接机服务（机场-酒店）<br/>· 单程送机服务（酒店-机场）<br/>· 每日自助午餐或自助晚餐一份",
            "attribute6": "条款与细则:<br/>1.至少连续入住两晚。",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "1",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "住宿+早餐优惠",
            "attribute4": "以最优惠的价格在旅途中享用早餐",
            "attribute5": "住宿+早餐优惠，可以享受客房优惠，免费宽带上网服务，延迟退房至下午4时，更额外免费享受以下一项附加服务：<br/>· 单程接机服务（机场-酒店）<br/>· 单程送机服务（酒店-机场）<br/>· 每日自助午餐或自助晚餐一份",
            "attribute6": "条款与细则:<br/>1.至少连续入住两晚。",
            "subth": [],
            "submenu": []
        }
    ]
}