{
    "folder": "../res/json/",
    "filename": "json_39_20171129191234.txt",
    "uniqueAttr": 23,
    "uniqueCont": 45,
    "thinfo": [{
        "attribute1": "poster",
        "attribute2": "name"
    }],
    "info": [{
        "mID": "1",
        "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171130173910166.png",
        "attribute2": "%E5%92%96%E5%95%A1",
        "subth": [{
            "subID": "",
            "attribute4": "name",
            "attribute5": "price"
        }],
        "submenu": [{
            "subID": "7",
            "attribute4": "%E6%8B%BF%E9%93%81%E5%92%96%E5%95%A1",
            "attribute5": "22%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "8",
            "attribute4": "%E7%84%A6%E7%B3%96%E6%8B%BF%E9%93%81",
            "attribute5": "26%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "9",
            "attribute4": "%E6%91%A9%E5%8D%A1%E5%92%96%E5%95%A1",
            "attribute5": "26%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "10",
            "attribute4": "%E7%BE%8E%E5%BC%8F%E5%92%96%E5%95%A1+",
            "attribute5": "18%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "11",
            "attribute4": "%E6%A6%9B%E6%9E%9C%E6%8B%BF%E9%93%81",
            "attribute5": "26%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "21",
            "attribute4": "%E5%86%B0%E5%92%96%E5%95%A1",
            "attribute5": "26%E5%85%83%2F%E6%9D%AF"
        }]
    }, {
        "mID": "2",
        "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171130173917341.png",
        "attribute2": "%E5%A5%B6%E8%8C%B6",
        "subth": [{
            "subID": "",
            "attribute8": "name",
            "attribute9": "price"
        }],
        "submenu": [{
            "subID": "13",
            "attribute8": "%E5%8D%A1%E5%B8%83%E5%A5%87%E8%AF%BA",
            "attribute9": "22%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "45",
            "attribute8": "%E5%A5%B6%E8%8C%B6+",
            "attribute9": "22%E5%85%83%2F%E6%9D%AF"
        }]
    }, {
        "mID": "4",
        "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171130173925108.png",
        "attribute2": "%E8%8A%B1%2F%E6%9E%9C%E8%8C%B6",
        "subth": [{
            "subID": "",
            "attribute10": "name",
            "attribute11": "price"
        }],
        "submenu": [{
            "subID": "14",
            "attribute10": "%E8%8A%92%E6%9E%9C%E4%BC%98%E6%A0%BC",
            "attribute11": "18%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "20",
            "attribute10": "%E6%9F%B3%E6%A9%99%E4%BC%98%E6%A0%BC",
            "attribute11": "18%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "39",
            "attribute10": "%E6%B0%B4%E6%9E%9C%E8%8C%B6+",
            "attribute11": "48%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "40",
            "attribute10": "%E7%8E%AB%E7%91%B0%E8%8A%B1%E8%8C%B6+",
            "attribute11": "48%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "41",
            "attribute10": "%E5%8A%9F%E5%A4%AB%E8%8C%B6++",
            "attribute11": "58%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "43",
            "attribute10": "%E8%8B%B1%E5%BC%8F%E7%BA%A2%E8%8C%B6+",
            "attribute11": "18%E5%85%83%2F%E6%9D%AF"
        }]
    }, {
        "mID": "5",
        "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171130173932955.png",
        "attribute2": "%E5%95%A4%E9%85%92",
        "subth": [{
            "subID": "",
            "attribute12": "name",
            "attribute13": "price"
        }],
        "submenu": [{
            "subID": "15",
            "attribute12": "1664%E5%95%A4%E9%85%92",
            "attribute13": "30%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "22",
            "attribute12": "%E9%9B%AA%E8%8A%B1%E8%84%B8%E8%B0%B1%E5%95%A4%E9%85%92",
            "attribute13": "30%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "23",
            "attribute12": "%E7%99%BE%E5%A8%81%E9%93%9D%E7%BD%90%E5%95%A4%E9%85%92%E7%BA%A2%E7%93%B6",
            "attribute13": "30%E5%85%83%2F%E6%9D%AF"
        }]
    }, {
        "mID": "6",
        "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171130173938847.png",
        "attribute2": "%E9%B8%A1%E5%B0%BE%E9%85%92",
        "subth": [{
            "subID": "",
            "attribute14": "name",
            "attribute15": "price"
        }],
        "submenu": [{
            "subID": "16",
            "attribute14": "%E7%A6%8F%E6%98%9F%E6%BE%B3%E5%A4%A7%E5%88%A9%E4%BA%9A%E6%A0%91%E7%86%8A",
            "attribute15": "128%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "31",
            "attribute14": "%E9%92%A6%E6%9E%97%E6%99%BA%E5%8A%9B%E7%81%AB%E7%8E%AB%E7%91%B0",
            "attribute15": "180%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "32",
            "attribute14": "%E9%92%A6%E6%9E%97%E6%BE%B3%E5%A4%A7%E5%88%A9%E4%BA%9A%E7%9F%B3%E6%9F%B1",
            "attribute15": "280%E5%85%83%2F%E6%9D%AF"
        }]
    }, {
        "mID": "25",
        "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171130173945514.png",
        "attribute2": "%E6%9E%9C%E6%B1%81",
        "subth": [{
            "subID": "",
            "attribute20": "name",
            "attribute21": "price"
        }],
        "submenu": [{
            "subID": "33",
            "attribute20": "%E9%B2%9C%E6%A6%A8%E8%A5%BF%E7%93%9C%E6%B1%81+",
            "attribute21": "20%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "34",
            "attribute20": "%E9%B2%9C%E6%A6%A8%E6%A9%99%E6%B1%81",
            "attribute21": "20%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "35",
            "attribute20": "%E5%A5%87%E5%BC%82%E6%9E%9C%E6%B1%81",
            "attribute21": "18%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "36",
            "attribute20": "%E8%8A%92%E6%9E%9C%E6%B1%81",
            "attribute21": "18%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "37",
            "attribute20": "%E7%BA%A2%E6%A0%91%E8%8E%93%E6%9E%9C%E6%B1%81",
            "attribute21": "18%E5%85%83%2F%E6%9D%AF"
        }, {
            "subID": "38",
            "attribute20": "%E7%99%BE%E9%A6%99%E6%9E%9C%E6%B1%81",
            "attribute21": "18%E5%85%83%2F%E6%9D%AF"
        }]
    }, {
        "mID": "26",
        "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171130173953814.png",
        "attribute2": "%E6%8B%BC%E7%9B%98",
        "subth": [{
            "subID": "",
            "attribute18": "name",
            "attribute19": "price"
        }],
        "submenu": [{
            "subID": "29",
            "attribute18": "%E6%B0%B4%E6%9E%9C%E6%8B%BC%E7%9B%98",
            "attribute19": "36%E5%85%83%2F%E7%9B%98"
        }, {
            "subID": "30",
            "attribute18": "%E5%9D%9A%E6%9E%9C%E6%8B%BC%E7%9B%98+",
            "attribute19": "36%E5%85%83%2F%E7%9B%98"
        }]
    }, {
        "mID": "28",
        "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171130174000348.png",
        "attribute2": "%E8%8B%8F%E6%89%93%E6%B0%B4",
        "subth": [{
            "subID": "",
            "attribute22": "name",
            "attribute23": "price"
        }],
        "submenu": [{
            "subID": "44",
            "attribute22": "%E7%89%9B%E6%B2%B9%E6%9E%9C%E6%B0%94%E6%B3%A1%E6%B0%B4",
            "attribute23": "18%E5%85%83%2F%E6%9D%AF"
        }]
    }]
}