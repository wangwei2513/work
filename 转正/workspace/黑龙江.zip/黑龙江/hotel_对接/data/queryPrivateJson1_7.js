{
"folder":"../res/json/",
"filename":"json_p_20170318145941.txt", 
"uniqueAttr":6, 
"uniqueCont":2, 
"thinfo":
[{"attribute1":"id","attribute2":"sort","attribute3":"picUrl","attribute4":"playUrl","attribute5":"name","attribute6":"nameEn"}],
"info":[
{"mID":"1", "attribute1":"1", "attribute2":"0", "attribute3":"http%3A%2F%2F10.102.13.41%2Fhotel_vod_cw%2Fres%2Fupload%2F170318150117347.png", "attribute4":"100000", "attribute5":"%E8%A7%86%E9%A2%911", "attribute6":"video1", "subth":[],"submenu":[]}, 
{"mID":"2", "attribute1":"2", "attribute2":"1", "attribute3":"http%3A%2F%2F10.102.13.41%2Fhotel_vod_cw%2Fres%2Fupload%2F170318150144759.png", "attribute4":"eee.ts", "attribute5":"%E8%A7%86%E9%A2%912", "attribute6":"video2", "subth":[],"submenu":[]}
]}