{
    "data": [{
            "Name": "关于酒店",
            "Category": 55,
            "Url": "http://10.177.64.2/hotel_vod/admin.php?app=admin&index=app&act=section-private-sign",
            "ID": 180,
            "Hotel": 39,
            "Icon": ""
        },
        {
            "Name": "酒店指南",
            "Category": 55,
            "Url": "http://10.177.64.2/hotel_vod/admin.php?app=admin&index=app&act=section-private-sign",
            "ID": 181,
            "Hotel": 39,
            "Icon": ""
        },
        {
            "Name": "优惠活动",
            "Category": 55,
            "Url": "http://10.177.64.2/hotel_vod/admin.php?app=admin&index=app&act=section-private-sign",
            "ID": 182,
            "Hotel": 39,
            "Icon": ""
        },
        {
            "Name": "餐厅酒吧",
            "Category": 55,
            "Url": "http://10.177.64.2/hotel_vod/admin.php?app=admin&index=app&act=section-private-sign",
            "ID": 183,
            "Hotel": 39,
            "Icon": ""
        },
        {
            "Name": "客户设施",
            "Category": 55,
            "Url": "http://10.177.64.2/hotel_vod/admin.php?app=admin&index=app&act=section-private-sign",
            "ID": 184,
            "Hotel": 39,
            "Icon": ""
        },
        {
            "Name": "会议设施",
            "Category": 55,
            "Url": "http://10.177.64.2/hotel_vod/admin.php?app=admin&index=app&act=section-private-sign",
            "ID": 185,
            "Hotel": 39,
            "Icon": ""
        }
    ]
}