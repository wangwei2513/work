
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",
			"attribute2": "sort",
            "attribute3": "name",
            "attribute4": "nameEn",
            "attribute5": "picUrl",
            "attribute6": "price"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "1",
            "attribute2": "0",
            "attribute3": "豪华型",
            "attribute4": "type1",
            "attribute5": "images/pic6_1.jpg",
            "attribute6": "88元"
        },{
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "电动型",
            "attribute4": "type2",
            "attribute5": "images/pic6_2.jpg",
            "attribute6": "88元"
        },{
            "mID": "3",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "经济型",
            "attribute4": "type1",
            "attribute5": "images/pic6_3.jpg",
            "attribute6": "99元"
        },{
            "mID": "4",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "舒适型",
            "attribute4": "type1",
            "attribute5": "images/pic4_4.jpg",
            "attribute6": "56元"
        },{
            "mID": "5",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "7座MPV",
            "attribute4": "type1",
            "attribute5": "images/pic6_5.jpg",
            "attribute6": "78元"
        },{
            "mID": "6",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "精英型",
            "attribute4": "type1",
            "attribute5": "images/pic6_6.jpg",
            "attribute6": "96元"
        }

    ]
}