{
    "folder": "../res/json/",
    "filename": "json_39_20171129170509.txt",
    "uniqueAttr": 3,
    "uniqueCont": 3,
    "thinfo": [{
        "attribute1": "picUrl",
        "attribute2": "picUrlBig",
        "attribute3": "intro"
    }],
    "info": [{
            "mID": "1",
            "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171201141643629.png",
            "attribute2": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171201141651115.jpg",
            "attribute3": "%E5%85%B1%E6%9C%89%E5%A4%A7%E3%80%81%E5%B0%8F%E4%BC%9A%E8%AE%AE%E5%AE%A49%E4%B8%AA%EF%BC%8C%E9%85%8D%E5%A4%87%E7%94%B5%E8%84%91%E6%8A%95%E5%BD%B1%E4%BB%AA%E3%80%81LED%E5%B1%8F%E3%80%81%E9%9F%B3%E5%93%8D%E8%88%9E%E5%8F%B0%E7%81%AF%E5%85%89%E7%B3%BB%E7%BB%9F%E7%AD%89%E7%8E%B0%E4%BB%A3%E5%8C%96%E4%BC%9A%E8%AE%AE%E8%AE%BE%E6%96%BD%EF%BC%8C%E5%8F%AF%E6%BB%A1%E8%B6%B3%E5%95%86%E5%8A%A1%E4%BC%9A%E8%AE%AE%E3%80%81%E6%B4%BD%E8%B0%88%E7%AD%BE%E7%BA%A6%E3%80%81%E6%96%B0%E9%97%BB%E5%8F%91%E5%B8%83%E3%80%81%E4%BA%A7%E5%93%81%E5%B1%95%E7%A4%BA%E3%80%81%E8%91%A3%E4%BA%8B%E3%80%81%E8%82%A1%E4%B8%9C%E4%BC%9A%E8%AE%AE%E3%80%81%E5%AD%A6%E6%9C%AF%E7%A0%94%E8%AE%A8%E7%AD%89%E9%9C%80%E6%B1%82%EF%BC%8C%E4%BC%9A%E8%AE%AE%E5%AE%A4%E6%91%86%E6%94%BE%E5%8F%AF%E6%A0%B9%E6%8D%AE%E4%BC%9A%E8%AE%AE%E6%80%A7%E8%B4%A8%E8%80%8C%E8%B0%83%E6%95%B4%E5%8A%9F%E8%83%BD%EF%BC%8C%E6%9C%89%E5%89%A7%E9%99%A2%E5%BC%8F%E3%80%81%E8%AF%BE%E5%A0%82%E5%BC%8F%E3%80%81%E5%AE%B4%E4%BC%9A%E5%BC%8F%E3%80%81U%E5%9E%8B%E5%8F%B0%E3%80%81%E8%91%A3%E4%BA%8B%E4%BC%9A%E5%BC%8F%E3%80%82%E6%98%AF%E6%82%A8%E4%BC%9A%E5%8A%A1%E9%A6%96%E9%80%89%E4%B9%8B%E5%9C%B0%E3%80%82",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "2",
            "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171201141658309.png",
            "attribute2": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171201141708448.jpg",
            "attribute3": "",
            "subth": [],
            "submenu": []
        },
        {
            "mID": "3",
            "attribute1": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171201141719417.png",
            "attribute2": "http%3A%2F%2F10.177.64.2%2Fhotel_vod%2Fres%2Fupload%2F171201141725248.jpg",
            "attribute3": "",
            "subth": [],
            "submenu": []
        }
    ]
}