// 餐厅酒吧
{
    "folder": "../res/json/",
    "filename": "json_p_20170320143224.txt",
    "uniqueAttr": 12,
    "uniqueCont": 1,
    "thinfo": [
        {
            "attribute1": "id",
            "attribute2": "sort",
            "attribute3": "name",
            "attribute4": "picUrl",
            "attribute5": "picUrlBig",
            "attribute6": "intro"
        }
    ],
    "info": [
        {
            "mID": "1",
            "attribute1": "1",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": ["images/pic8_1.jpg","images/pic7_1.jpg","images/pic9_1.jpg"],
            "attribute5": ["images/pic8_1.jpg","images/pic7_1.jpg","images/pic9_1.jpg"],
            "attribute6": "<p>哈尔滨香格里拉大酒店拥有404间装修精美的客房和套房，空间宽敞舒适、装修风格时尚典雅，可凭窗饱览都市风光或松花江美景。客房配有舒适柔软的大床及豪华鹅绒枕头，让宾客尽享舒适甜美的睡眠。</p>",
            "subth": [],
            "submenu": []
        }
    ]
}