// 聘请导游
{
    "folder": "../res/json/",
    "filename": "json_p_20170320143224.txt",
    "uniqueAttr": 12,
    "uniqueCont": 1,
    "thinfo": [
        {
            "attribute1": "id",
            "attribute2": "sort",
            "attribute3": "name",
            "attribute4": "nameDetail",
            "attribute5": "price",
            "attribute6": "sex",
            "attribute7": "language"
        }
    ],
    "info": [
        {
            "mID": "1",
            "attribute1": "1",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": "",
            "attribute5": "200",
            "attribute6": "男",
            "attribute7": "国语",
            "subth": [],
            "submenu": []
        },{
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": "",
            "attribute5": "600",
            "attribute6": "男",
            "attribute7": "韩语",
            "subth": [],
            "submenu": []
        },{
            "mID": "3",
            "attribute1": "3",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": "",
            "attribute5": "200",
            "attribute6": "女",
            "attribute7": "国语",
            "subth": [],
            "submenu": []
        },{
            "mID": "4",
            "attribute1": "4",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": "",
            "attribute5": "600",
            "attribute6": "女",
            "attribute7": "韩语",
            "subth": [],
            "submenu": []
        },{
            "mID": "5",
            "attribute1": "5",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": "",
            "attribute5": "300",
            "attribute6": "男",
            "attribute7": "英语",
            "subth": [],
            "submenu": []
        },{
            "mID": "6",
            "attribute1": "6",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": "",
            "attribute5": "600",
            "attribute6": "男",
            "attribute7": "日语",
            "subth": [],
            "submenu": []
        },{
            "mID": "7",
            "attribute1": "7",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": "",
            "attribute5": "300",
            "attribute6": "女",
            "attribute7": "英语",
            "subth": [],
            "submenu": []
        },{
            "mID": "8",
            "attribute1": "8",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": "",
            "attribute5": "600",
            "attribute6": "女",
            "attribute7": "日语",
            "subth": [],
            "submenu": []
        }
    ]
}