// 关于酒店
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",//素材id
            "attribute2": "sort", //层次
            "attribute3": "name", //名称
            "attribute4": "picUrl", //图片地址
            "attribute5": "picUrlBig", //大图、、其实和小图的地址一样
            "attribute6": "intro"  //文字内容
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "%E8%A1%8C%E6%94%BF%E4%BC%9A%E6%89%80",
            "attribute4": ["images/pic7_1.jpg"],
            "attribute5": ["images/pic7_1.jpg"],
            "attribute6": "<p>从沉睡中醒来，感觉如在家般舒适和放松。昨晚的路途依然历历在目，不觉已身处哈尔滨香格里拉大酒店。宽宽的大床，天鹅绒枕头曾带给您最舒适的享受。但此刻，心中总是惦记着未来几天的旅程，睡意敌不过兴奋。</p><p>心血来潮，掀开窗帘，窗外的冰雪之城欢迎您的到来。眺望远方，美丽的松花江在晨光中像珠宝一样闪闪发光。</p><p>利索地穿上衣服，到咖啡苑享用早餐，把香</p> <p>心血来潮，掀开窗帘，窗外的冰雪之城欢迎您的到来。眺望远方，美丽的松花江在晨光中像珠宝一样闪闪发光。</p>",
            "subth": [],
            "submenu": []
        }
    ]
}