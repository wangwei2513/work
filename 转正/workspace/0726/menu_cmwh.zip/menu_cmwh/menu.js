[{
	"linkUrl": "",
	"listType": "tv_words",
	"name": "�Ļ���ɫ",
	"navigator": "",
	"nodePath": "data/whts"
},{
	"linkUrl": "",
	"listType": "tv_square",
	"name": "��ɫũҵ",
	"navigator": "",
	"nodePath": "data/lsny"
}]
