{
	"blurImageUrl": "",
	"clickable": 0,
	"enName": "yjtxyey",
	"entryCombinedImage": "http://zhsq.hfcatv.com.cn:80/appcmsFiles/1482848020254516913.jpg",
	"entryWord": "԰�������׶�԰",
	"focusImageUrl": "http://zhsq.hfcatv.com.cn:80/appcmsFiles/",
	"isManaged": "notManaged",
	"linkUrl": "",
	"listType": "",
	"name": "԰�������׶�԰",
	"navigator": "԰�������׶�԰",
	"newAdd": 0,
	"nodePath": "yjtxyey",
	"subNodeFocusCombinedImage": "http://zhsq.hfcatv.com.cn:80/appcmsFiles/"
}