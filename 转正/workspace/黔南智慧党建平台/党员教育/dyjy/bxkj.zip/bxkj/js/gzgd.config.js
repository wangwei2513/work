var cpcom_config = {
    'epg_host':'http://10.21.4.2/gzgd/STBindex',
    'version' :'1.0.0.0.0-STD-release'
}