{
    "blurImageUrl": "",
    "clickable": 1,
    "enName": "dyjy",
    "entryCombinedImage": "",
    "entryWord": "",
    "focusImageUrl": "",
    "isManaged": "managed",
    "linkUrl": "",
    "listType": "tv_words",
    "name": "ѧϰ����",
    "navigator": "��Ա����>��Ա����",
    "newAdd": 0,
    "nodePath": "jbcs",
    "subNodeFocusCombinedImage": ""
}