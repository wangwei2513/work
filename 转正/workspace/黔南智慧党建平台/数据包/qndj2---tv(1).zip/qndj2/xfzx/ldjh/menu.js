[{
	"blurImageUrl": "",
	"clickable": 1,
	"enName": "pjdt",
	"entryWord": "",
	"focusImageUrl": "",
	"isManaged": "managed",
	"linkUrl": "",
	"listType": "list",
	"name": "��ѧ����",
	"navigator": "",
	"newAdd": 1,
	"nodePath": "gxdjt"
}, {
	"blurImageUrl": "",
	"clickable": 1,
	"enName": "dmz",
	"entryWord": "",
	"focusImageUrl": "",
	"isManaged": "managed",
	"linkUrl": "",
	"listType": "list",
	"name": "��������",
	"navigator": "",
	"newAdd": 0,
	"nodePath": "ysjz"
}
]