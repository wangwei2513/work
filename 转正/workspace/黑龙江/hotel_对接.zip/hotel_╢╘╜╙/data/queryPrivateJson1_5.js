
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",
			"attribute2": "sort",
            "attribute3": "serviceName",
            "attribute4": "serviceNameEn",
            "attribute5": "serviceTime",
            "attribute6": "price"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "1",
            "attribute2": "0",
            "attribute3": "西裤、短裙、衬衫、T恤衫、牛仔裤、风衣",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "30元/件"
        },{
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "西装上衣、夹克、毛伊、青丝衬衫、旗袍、长裙",
            "attribute4": "type2",
            "attribute5": "90分钟",
            "attribute6": "30元/件"
        },{
            "mID": "3",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "西裤、短裙、衬衫、T恤衫、牛仔裤、风衣",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "30元/件"
        },{
            "mID": "4",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "西裤、短裙、衬衫、T恤衫、牛仔裤、风衣",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "30元/件"
        },{
            "mID": "5",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "西裤、短裙、衬衫、T恤衫、牛仔裤、风衣",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "30元/件"
        },{
            "mID": "6",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "西裤、短裙、衬衫、T恤衫、牛仔裤、风衣",
            "attribute4": "type1",
            "attribute5": "90分钟",
            "attribute6": "30元/件"
        }

    ]
}