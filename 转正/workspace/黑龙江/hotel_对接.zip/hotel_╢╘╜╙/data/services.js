{
stbNoExist: "false",
data: {
Phone: "0755",
Logo: "http://192.168.18.213:8080/ContentWS/res/Image-25-0-hotelicon.unknow",
HelloEN: "Ramada is an international hotel brand in the world's largest hotel group -- Wyndham San Jose Hotel group, founded in 1954 in America, was named as RAMADA INTERNATIONAL, in 1959 changed its name to RAMADA, the same year the first franchise, marking the brand and management entered the mature stage. After the successful development of the North American, South American and European market, in 1981, began to enter the Ramada Asia Pacific market. Now, in the famous brand Ramada is in more than 50 countries, more than 800 of the world in many areas has nearly 900 international hotel. After years of hard work, has developed 48 Chinese currently in the Ramada Hotel, Beijing, involving Shanghai, Suzhou, Yangzhou, Xiamen, Shenzhen, Sanya, Chongqing and Dalian. At the end of 2013 3 Wyndham San Jose Hotel group announced in 2014 before the opening of 8 new Chinese in Ramada Hotel, to continue to expand the Ramada brand business in China",
HelloCN: "华美达是全球最大的酒店集团——温德姆酒店集团旗下的一个国际酒店品牌，于1954年在美国成立，当时命名为RAMADA INTERNATIONAL，1959年更名为RAMADA，同年第一次出售特许经营权，标志着品牌和管理进入成熟期。在相继成功开拓了北美、南美和欧洲市场后，1981年，华美达开始进军亚太市场。现在，华美达已是在全球50多个国家、逾800多个地区拥有近900家国际酒店的著名品牌。经过多年来的打拼，华美达目前在中国已经发展48家酒店，涉及上海，北京，苏州，扬州，厦门，深圳，三亚，重庆及大连等地。2013年3月底温德姆酒店集团宣布将于2014年前再在中国开设8家全新华美达酒店，以继续在国内扩充华美达品牌业务",
Name: "华美达酒店",
ServiceID: 1208,
Httpaddr: "http://httpdvb.tsg.homed.me:13690/httpdvb?chnlname=hdszdsj&playtype=http&auth=no",
Date: "2015-03-17",
NameEn: "Ramada",
Address: "",
ID: 25,
noCheckIn: "false",
Frequency: 315
},
room: {
User: "xull",
ROOM: 197,
inDate: "2015-11-25 00:00:00.0",
Welcome_img: "http://192.168.18.213/hotel_vod_cw/res/upload/151123140013141.jpg",
lan: 0,
userSex: "1",
seehttp: 0,
ROOMNum: 2016
}
}