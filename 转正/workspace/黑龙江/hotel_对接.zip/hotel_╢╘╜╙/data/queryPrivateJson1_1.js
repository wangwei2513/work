
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",
			"attribute2": "sort",
            "attribute3": "name",
            "attribute4": "nameEn",
            "attribute5": "picUrl",
            "attribute6": "price"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "1",
            "attribute2": "0",
            "attribute3": "春意盎然双味鸡",
            "attribute4": "type1",
            "attribute5": "images/pic3_1.jpg",
            "attribute6": "109元"
        },{
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "一片冰心在玉壶",
            "attribute4": "type2",
            "attribute5": "images/pic3_2.jpg",
            "attribute6": "88元"
        },{
            "mID": "3",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "话梅飘雪糖排",
            "attribute4": "type1",
            "attribute5": "images/pic3_3.jpg",
            "attribute6": "99元"
        },{
            "mID": "4",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "白色恋人",
            "attribute4": "type1",
            "attribute5": "images/pic3_4.jpg",
            "attribute6": "56元"
        },{
            "mID": "5",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "名人酱味双拼",
            "attribute4": "type1",
            "attribute5": "images/pic3_5.jpg",
            "attribute6": "78元"
        },{
            "mID": "6",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "李庄白肉",
            "attribute4": "type1",
            "attribute5": "images/pic3_6.jpg",
            "attribute6": "96元"
        },{
            "mID": "7",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "干拌小牛腱",
            "attribute4": "type1",
            "attribute5": "images/pic3_6.jpg",
            "attribute6": "12元"
        }

    ]
}