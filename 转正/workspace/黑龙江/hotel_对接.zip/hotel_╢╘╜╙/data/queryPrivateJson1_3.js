
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",
			"attribute2": "sort",
            "attribute3": "name",
            "attribute4": "nameEn",
            "attribute5": "picUrl",
            "attribute6": "price"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "1",
            "attribute2": "0",
            "attribute3": "登山杖",
            "attribute4": "type1",
            "attribute5": "images/pic4_1.jpg",
            "attribute6": "109"
        },{
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "雨伞",
            "attribute4": "type2",
            "attribute5": "images/pic4_2.jpg",
            "attribute6": "88"
        },{
            "mID": "3",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "雨衣",
            "attribute4": "type1",
            "attribute5": "images/pic4_3.jpg",
            "attribute6": "99"
        },{
            "mID": "4",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "吹风机",
            "attribute4": "type1",
            "attribute5": "images/pic4_4.jpg",
            "attribute6": "56"
        },{
            "mID": "5",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "移动电源",
            "attribute4": "type1",
            "attribute5": "images/pic4_5.jpg",
            "attribute6": "78"
        },{
            "mID": "6",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "网球拍",
            "attribute4": "type1",
            "attribute5": "images/pic4_6.jpg",
            "attribute6": "96"
        }

    ]
}