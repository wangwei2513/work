
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",
			"attribute2": "sort",
            "attribute3": "name",
            "attribute4": "nameEn",
            "attribute5": "picUrl",
            "attribute6": "price"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "1",
            "attribute2": "0",
            "attribute3": "鲜花礼盒",
            "attribute4": "type1",
            "attribute5": "images/pic3_1.jpg",
            "attribute6": "109"
        },{
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "11朵白玫瑰",
            "attribute4": "type2",
            "attribute5": "images/pic3_2.jpg",
            "attribute6": "88"
        },{
            "mID": "3",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "9朵百合花",
            "attribute4": "type1",
            "attribute5": "images/pic3_3.jpg",
            "attribute6": "99"
        },{
            "mID": "4",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "桔梗/小雏菊",
            "attribute4": "type1",
            "attribute5": "images/pic3_4.jpg",
            "attribute6": "56"
        },{
            "mID": "5",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "12朵粉玫瑰",
            "attribute4": "type1",
            "attribute5": "images/pic3_5.jpg",
            "attribute6": "78"
        },{
            "mID": "6",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "康乃馨单只礼盒",
            "attribute4": "type1",
            "attribute5": "images/pic3_6.jpg",
            "attribute6": "96"
        }

    ]
}