// 餐厅酒吧
{
    "folder": "../res/json/",
    "filename": "json_p_20170320143224.txt",
    "uniqueAttr": 12,
    "uniqueCont": 1,
    "thinfo": [
        {
            "attribute1": "id",
            "attribute2": "sort",
            "attribute3": "name",
            "attribute4": "picUrl",
            "attribute5": "picUrlBig",
            "attribute6": "intro"
        }
    ],
    "info": [
        {
            "mID": "1",
            "attribute1": "1",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": ["images/pic9_1.jpg","images/pic8_1.jpg","images/pic7_1.jpg","images/pic8_1.jpg","images/pic7_1.jpg"],
            "attribute5": ["images/pic9_1.jpg","images/pic8_1.jpg","images/pic7_1.jpg","images/pic8_1.jpg","images/pic7_1.jpg"],
            "attribute6": "<p> 作为哈尔滨市内首家国际豪华酒店，这里是承办会议、宴会或社交活动的理想场地。酒店时尚的环境、专业的策划、悉心的服务和各类功能厅，是举办成功、愉快的活动的有力保障。</p><p>大型宴会厅富丽堂皇，大型吊灯璀璨夺目，略带欧陆宫廷风格，可容纳千余宾客。宴会厅还拥有先进的视听设备，包括同声传译系统。另有11间精心布置的功能厅。</p>",
            "subth": [],
            "submenu": []
        }
    ]
}