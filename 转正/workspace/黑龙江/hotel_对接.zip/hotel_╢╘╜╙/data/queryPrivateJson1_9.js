
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",
			"attribute2": "sort",
            "attribute3": "name",
            "attribute4": "nameEn",
            "attribute5": "type",
            "attribute6": "time"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "1",
            "attribute2": "0",
            "attribute3": "洗衣服务提醒",
            "attribute4": "type1",
            "attribute5": "普通",
            "attribute6": "2017-04-18"
        },{
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "早餐提醒",
            "attribute4": "type2",
            "attribute5": "普通",
            "attribute6": "2017-04-18"
        },{
            "mID": "3",
            "attribute1": "3",
            "attribute2": "0",
            "attribute3": "午餐提醒",
            "attribute4": "type1",
            "attribute5": "普通",
            "attribute6": "2017-04-18"
        },{
            "mID": "4",
            "attribute1": "4",
            "attribute2": "0",
            "attribute3": "欢迎入住",
            "attribute4": "type1",
            "attribute5": "普通",
            "attribute6": "2017-04-18"
        }
    ]
}