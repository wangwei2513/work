
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "ROOMNum",
            "attribute2": "ROOMType",
            "attribute3": "orderMan",
            "attribute4": "inDate",
            "attribute5": "totalChargeMoney",
			"attribute6": "User"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "1201",
            "attribute2": "海景房",
            "attribute3": "杨先生",
            "attribute4": "2017-04-10",
            "attribute5": 220,
            "attribute6": "李刚",
            "subth": [{"subID": "","attribute8":"projectType","attribute9":"consumeType","attribute10":"chargeMoney","attribute11":"chargeTime","attribute12":"remark"}],
            "submenu": [{"subID": "4","attribute8":"房费","attribute9":"餐饮","attribute10":"30","attribute11":"04-17 08:30:22","attribute12":""},{"subID": "4","attribute8":"洗衣","attribute9":"餐饮","attribute10":"30","attribute11":"04-17 08:30:22","attribute12":""},{"subID": "4","attribute8":"午餐","attribute9":"租车","attribute10":"30","attribute11":"04-17 08:30:22","attribute12":""}]
        }
    ]
}