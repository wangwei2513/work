{"stbNoExist":"false",
"data":
{
	"Phone":"0755",
	"Logo":"http://192.168.18.213:8080/ContentWS/res/Image-25-0-hotelicon.unknow",
	"HelloEN":"Ramada is an international hotel brand in the world's largest hotel group -- Wyndham San Jose Hotel group, founded in 1954 in America, was named as RAMADA INTERNATIONAL, in 1959 changed its name to RAMADA, the same year the first franchise, marking the brand and management entered the mature stage. After the successful development of the North American, South American and European market, in 1981, began to enter the Ramada Asia Pacific market. Now, in the famous brand Ramada is in more than 50 countries, more than 800 of the world in many areas has nearly 900 international hotel. After years of hard work, has developed 48 Chinese currently in the Ramada Hotel, Beijing, involving Shanghai, Suzhou, Yangzhou, Xiamen, Shenzhen, Sanya, Chongqing and Dalian. At the end of 2013 3 Wyndham San Jose Hotel group announced in 2014 before the opening of 8 new Chinese in Ramada Hotel, to continue to expand the Ramada brand business in China",
	"HelloCN":'城市名人酒店是集团下属的一家旗舰店，地处顶级中央商务区，毗邻天府广场、成都最大文化艺术中心，紧靠高端百货购物中心、成都市繁华商业街。酒店推出以"YES BOSS"的服务理念，以"您是我们的老板，我们是您的贴身管家，商务秘书"为服务形象推出了BOSS卡。酒店豪华高贵的装饰，高素质的员工，配备专业化的服务体系。城市名人酒店是集团下属的一家旗舰店，地处顶级中央商务区，毗邻天府广场、成都最大文化艺术中心，紧靠高端百货购物中心、成都市繁华商业街。酒店推出以"YES BOSS"的服务理念，以"您是我们的老板，我们是您的贴身管家，商务秘书"为服务形象推出了BOSS卡。酒店豪华高贵的装饰，高素质的员工，配备专业化的服务。配备专业化的服务。',
	"ServiceID":1208,
	"Httpaddr":"http://httpdvb.tsg.homed.me:13690/httpdvb?chnlname=hdszdsj&playtype=http&auth=no",
	"Date":"2015-03-17",
	"NameEn":"Ramada",
	"Address":"",
	"ID":25,
	"noCheckIn":"false",
	"Frequency":315
},
"room":{
	"User":"吴刚",
	"ROOM":197,
	"inDate":"2015-11-25 00:00:00.0",
	"Welcome_img":"http://192.168.18.213/hotel_vod_cw/res/upload/151123140013141.jpg",
	"lan":0,
	"userSex":"0",
	"seehttp":0,
	"ROOMNum":2016
}}