// 旅游路线
{
    "folder": "../res/json/",
    "filename": "json_p_20170318150432.txt",
    "uniqueAttr": 7,
    "uniqueCont": 2,
    "thinfo": [
        {
            "attribute1": "id",
            "attribute2": "sort",
            "attribute3": "name",
            "attribute4": "nameEn",
            "attribute5": "picUrl",
            "attribute6": "tel"
        }
    ],
    "info": [
        {
            "mID": "2",
            "attribute1": "2",
            "attribute2": "1",
            "attribute3": "旅游路线咨询及预订电话",
            "attribute4": "",
            "attribute5": "",
            "attribute6": "8622-54566666",
            "subth": [
                {
                    "subID": "",
                    "attribute12": "id",
                    "attribute13": "sort",
                    "attribute14": "name",
                    "attribute16": "picUrl",
                    "attribute17": "price",
                    "attribute18": "priceInfo",
                    "attribute19": "tel"
                }
            ],
            "submenu": [
                {
                    "subID": "4",
                    "attribute12": "1",
                    "attribute13": "0",
                    "attribute14": "<哈尔滨5日自由行>畅游冰城 酒店自选 感受北国异域风情",
                    "attribute16": "",
                    "attribute17": "88",
                    "attribute18": "",
                    "attribute19": "8622-54566666"
                },{
                    "subID": "5",
                    "attribute12": "2",
                    "attribute13": "1",
                    "attribute14": "<哈尔滨1日游>欧式风情 东北特色",
                    "attribute16": "",
                    "attribute17": "88",
                    "attribute18": "",
                    "attribute19": "8622-54566666"
                },{
                    "subID": "6",
                    "attribute12": "3",
                    "attribute13": "1",
                    "attribute14": "<哈尔滨-中央大街-索菲亚教堂广场1日游>漫步百年老街，体验欧陆风情",
                    "attribute16": "",
                    "attribute17": "88",
                    "attribute18": "",
                    "attribute19": "8622-54566666"
                },{
                    "subID": "7",
                    "attribute12": "4",
                    "attribute13": "1",
                    "attribute14": "<英杰欢乐王国水世界直通车1日游>哈尔滨起止 室内大型水上乐园",
                    "attribute16": "",
                    "attribute17": "88",
                    "attribute18": "",
                    "attribute19": "8622-54566666"
                },{
                    "subID": "8",
                    "attribute12": "5",
                    "attribute13": "1",
                    "attribute14": "<英杰温泉直通车1日游>哈尔滨起止 温泉疗养 室内外温泉",
                    "attribute16": "",
                    "attribute17": "88",
                    "attribute18": "",
                    "attribute19": "8622-54566666"
                },{
                    "subID": "9",
                    "attribute12": "6",
                    "attribute13": "1",
                    "attribute14": "<哈尔滨宾县英杰温泉1日游>体验北方高寒地区室外温泉",
                    "attribute16": "",
                    "attribute17": "88",
                    "attribute18": "",
                    "attribute19": "8622-54566666"
                },{
                    "subID": "10",
                    "attribute12": "7",
                    "attribute13": "1",
                    "attribute14": "<英杰欢乐王国水世界直通车1日游>哈尔滨起止 室内大型水上乐园",
                    "attribute16": "",
                    "attribute17": "88",
                    "attribute18": "",
                    "attribute19": "8622-54566666"
                },{
                    "subID": "11",
                    "attribute12": "8",
                    "attribute13": "1",
                    "attribute14": "<哈尔滨1日游>欧式风情 东北特色",
                    "attribute16": "",
                    "attribute17": "88",
                    "attribute18": "",
                    "attribute19": "8622-54566666"
                }
            ]
        }
    ]
}