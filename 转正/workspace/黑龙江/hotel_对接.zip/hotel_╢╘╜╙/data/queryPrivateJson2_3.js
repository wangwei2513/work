// 餐厅酒吧
{
    "folder": "../res/json/",
    "filename": "json_p_20170320143224.txt",
    "uniqueAttr": 12,
    "uniqueCont": 1,
    "thinfo": [
        {
            "attribute1": "id",
            "attribute2": "sort",
            "attribute3": "name",
            "attribute4": "picUrl",
            "attribute5": "picUrlBig",
            "attribute6": "intro"
        }
    ],
    "info": [
        {
            "mID": "1",
            "attribute1": "1",
            "attribute2": "1",
            "attribute3": "",
            "attribute4": ["images/pic7_1.jpg","images/pic8_1.jpg","images/pic9_1.jpg"],
            "attribute5": ["images/pic7_1.jpg","images/pic8_1.jpg","images/pic9_1.jpg"],
            "attribute6": "<p> 哈尔滨香格里拉酒店提供哈尔滨首屈一指的餐饮选择。咖啡苑不仅为您准备了国际自助餐，还提供全天单点食物服务。如想到正式的场合，香宫最理想不过。香宫以其地道的广东菜与本地黑龙江特色菜而名声远扬。</p><p>轻松安静的大堂酒廊是会议与夜聊的最佳场所，一应俱全的吧台服务让您称心如意，美味的小吃随时供应。</p>",
            "subth": [],
            "submenu": []
        }
    ]
}