﻿ access_token = "TOKEN50001002";
var Flag = 0;
var globalDomain = ".homed.me";

//²㋔µ㲥id
//var testMacAddr = "00-27-1a-00-6b-2c";

var testMacAddr = "00-27-1a-00-6b-2c"//¹«˾liancm²㋔ѨҪ ՝ʱ±£´
var deviceType = 1;//¹«˾²㋔ֻŜԃmac  ՝ʱ±£´//0£ºȫ²¿£»1£º»�£»2£ºCA¿¨£»3£º˖»�ºpad£»5£ºµ腔 ԫʏĦtestCardId¶Փ¦

//Ж³¡ʵ¼ʵôestMacAddrº̤eviceType --ʵ¼ˏֳ¡ʹԃca¿¨ºŵȂ½
if(typeof CAManager != "undefined"){
	testMacAddr = CAManager.cardSerialNumber;
	deviceType = 2;
}
//var slaveAddr = 'http://api.slave.homed.me:13160';
//var	accountAddr="http://access.homed.me";
var slaveAddr = ["http://10.14.41.245:13160",'http://slave.homed.me:13160'][Flag];
var	accountAddr= ["http://10.14.41.244:12690","http://access.homed.me"][Flag];
var cfxwLabel = 137;
function $(_id) {
    return document.getElementById(_id);
}
//´󓡲㋔
function iDebug(str) {
    if (navigator.appName.indexOf("iPanel") != -1) {
        iPanel.debug(str); //¼ڈ蒪¿´´󓡵Ŋ±¼䣬¿ʒԸģºiPanel.debug(str, 2);
    } else if (navigator.appName.indexOf("Opera") != -1) {
        opera.postError(str);
    } else if (navigator.appName.indexOf("Netscape") != -1 || navigator.appName.indexOf("Google") != -1) {
        console.log(str);
    }
}

function sendAjax(url, data, callback) {
    var xmlhttp;
    var isAsync = false;;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        if (typeof arguments.callee.activeXString != "string") {
            var versions = ["MSXML2.XMLHttp.6.0", "MSXML2.XMLHttp.3.0", "MSXML2.XMLHttp"];
            for (var i = 0, len = versions.length; i < len; i++) {
                try {
                    xmlhttp = new ActiveXObject(versions[i]);
                    arguments.callee.activeXString = versions[i];
                } catch (ex) {
                    //͸¹�                 if (len - 1 == i) {
                        throw new Error("there is no xmlhttprequest object available");
                    }
                }
            }
        } else {
            xmlhttp = new ActiveXObject(arguments.callee.activeXString);
        }
    }
    xmlhttp.overrideMimeType("text/html; charset=UTF-8");
    xmlhttp.onreadystatechange = function() {
        iDebug("readyState:---------" + xmlhttp.readyState + "status:-----" + xmlhttp.status);
        if (xmlhttp.readyState == 4) {

            if (xmlhttp.status == 200 || xmlhttp.status == 0) {
                callback(xmlhttp.responseText);
            }
        }
    }
    if (data != null && typeof data != "undefined") {
        xmlhttp.open("POST", url, isAsync);
        xmlhttp.send(data);
    } else {
        xmlhttp.open("GET", url, isAsync);
        xmlhttp.send(null);
    }
}
/*----------------------------------------·µ»ַٗ�ؖ³¤¶ƠӢτ»󍙊㘖·�Рµ±Ԛһ¸�ԭ--------------------------------------------------------*/
/*
 *str:´«ɫµŗַ� *len:ؖ·�خ´󳤶ƍ
 *·µ»ؽو¡µŗַ� */
function getStrChineseLen(str, len) {
    var w = 0;
    str = str.replace(/[ ]*$/g, "");
    if (getStrChineseLength(str) > len) {
        for (var i = 0; i < str.length; i++) {
            var c = str.charCodeAt(i);
            var flag = 0;
            //µ¥ؖ½ڼѱ
            if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
                w++;
                flag = 0;
            } else {
                w += 2;
                flag = 1;
            }
            if (parseInt((w + 1) / 2) > len) {
                if (flag == 1) return str.substring(0, i - 1) + ".."; //ў¸¬sunny,·V¹»»ѐ...
                else return str.substring(0, i - 2) + "..";
                break;
            }

        }
    }
    return str;
}

function getStrChineseLength(str) {
    str = str.replace(/[ ]*$/g, "");
    var w = 0;
    for (var i = 0; i < str.length; i++) {
        var c = str.charCodeAt(i);
        //µ¥ؖ½ڼѱ
        if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
            w++;
        } else {
            w += 2;
        }
    }
    var length = w % 2 == 0 ? (w / 2) : (parseInt(w / 2) + 1);
    return length;
}
//*******************************»򈡱뗼URLµĲϊ�t************************//
/**
 * »򈡱뗼URLµĲϊ�@_key£ºؖ·�²»֧³׊���¬µëey£©
 * @_url£ºؖ·�£¨window£©.location.href£¬ʹԃʱ±񏳴«ɫ·Ʒindow¶Տ񋈠* @_spliter£ºؖ·�²ϊ��
 * עӢ£º
 * 	1¡¢ɧ²»´畚ָ¶¨¼�ؿַ֗�·½±䖱½ԏՊ¾£¬ʹԃʱעӢƐ¶͍
 * 	2¡¢·Ǳ뗼URLϰԃ
 * 	3¡¢query£¨£¿£©ԫhash£¨#£©א´畚¼��Ӕ˽ة·µ»֍
 */
function getUrlParams(_key, _url, _spliter) {
    //iPanel.debug("common.js===getUrlParams====_url" + _url);
    if (typeof(_url) == "object") {
        var url = _url.location.href;
    } else {
        var url = _url ? _url : window.location.href;
    }
    if (url.indexOf("?") == -1 && url.indexOf("#") == -1) {
        return "";
    }
    var spliter = _spliter || "&";
    var spliter_1 = "#";
    var haveQuery = false;
    var x_0 = url.indexOf(spliter);
    var x_1 = url.indexOf(spliter_1);
    var urlParams;
    if (x_0 != -1 || x_1 != -1 || url.indexOf("?") != -1) {
        if (url.indexOf("?") != -1) urlParams = url.split("?")[1];
        else if (url.indexOf("#") != -1) urlParams = url.split("#")[1];
        else urlParams = url.split(spliter)[1];
        if (urlParams.indexOf(spliter) != -1 || urlParams.indexOf(spliter_1) != -1) { //¿ʄܳ�url?a=1&b=3#c=2&d=5 url?a=1&b=2 url#a=1&b=2µŇꀶ¡£
            var v = [];
            if (urlParams.indexOf(spliter_1) != -1) {
                v = urlParams.split(spliter_1);
                urlParams = [];
                for (var x = 0; x < v.length; x++) {
                    urlParams = urlParams.concat(v[x].split(spliter));
                }
            } else {
                urlParams = urlParams.split(spliter);
            }
        } else {
            urlParams = [urlParams];
        }
        haveQuery = true;
    } else {
        urlParams = [url];
    }
    var valueArr = [];
    for (var i = 0, len = urlParams.length; i < len; i++) {
        var params = urlParams[i].split("=");
        if (params[0] == _key) {
            valueArr.push(params[1]);
        }
    }
    if (valueArr.length > 0) {
        if (valueArr.length == 1) {
            return valueArr[0];
        }
        return valueArr;
    }
    return "";
}

function setGlobalVar(_name, _value) { //ʨ׃ȫ¾ֱ偿
    if (navigator.appName.indexOf("iPanel") != -1) {
        iPanel.setGlobalVar(_name, _value);
    } else {
        var b1 = JSON.stringify(_value);
        sessionStorage.setItem(_name, b1);
    }
}

function getGlobalVar(_name) { //»򈢈«¾ֱ偿
    if (navigator.appName.indexOf("iPanel") != -1) {
        return iPanel.getGlobalVar(_name);
    } else {
        return JSON.parse(sessionStorage.getItem(_name));
    }
}

function delGlobalVar(_name) { //ɾ³�偿
    if (navigator.appName.indexOf("iPanel") != -1) {
        iPanel.delGlobalVar(_name);
    } else {
        sessionStorage.removeItem(_name);
    }
}


function showTime() {
    //setInterval(function() {
    $("timer").innerHTML = new Date().Format("yyyy-MM-dd");
    //}, 1000);
}
Date.prototype.Format = function(fmt) {
    var o = {
        "y+": this.getYear(),
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};
function ajaxClass(_url, _successCallback, _failureCallback, _urlParameters, _callbackParams, _async, _charset, _timeout, _frequency, _requestTimes, _frame) {
    /**
     * AJAXͨ¹�POSTµķ½ʽ½�²½»󍬲½ȫȳ˽¾ۍ
     * עӢ£º
     * 	1¡¢·�40 No Contentˇ±»HTTP±뗼˓Ϊȫȳ³ɹ¦µ
     * 	2¡¢ҪʹԃresponseXML¾Ͳ»Ŝʨ׃_charset£¬ѨҪֱ½Ӵ«ɫnull
     * 	3¡¢_frame£¬¾ΊȊµ}»¯±¾¶Տ󶅒³Ħ¶Տ󣭇뾡±£֤׼ȷ£¬±݃ⴶЖőӔ½㋍µŒ쳣
     */
    /**
     * @param{string} _url: ȫȳ·¾¶
     * @param{function} _successCallback: ȫȳ³ɹ¦º�еĻص��»¸��©չһ¸�ºnew XMLHttpRequest()µķµ»ٖµ
     * @param{function} _failureCallback: ȫȳʧ°گ³¬ʱº�еĻص���¦»ص�£ԃ.status£¬.statusText
     * @param{string} _urlParameters: ȫȳ·¾¶̹ѨҪ´«µݵõrl²ϊ�
     * @param{*} _callbackParams: ȫȳ½⋸ʱ՚»ص��분²ϊ�¨ӥŚɝ
     * @param{boolean} _async: ˇ·򓬲½µ�¬ĬɏΪtrue£ºӬ²½£¬false£ºͬ²½
     * @param{string} _charset: ȫȳ·µ»صŊ�ძ¸򊽣¬²¿·թPanel䰀F�E6²»֧³֣¬ѨҪ·µ»טML¶Տ􊱲»Ŝʹԃ
     * @param{number} _timeout: ÿ´η¢³�󻳶೤ʱ¼党ûԐ³ɹ¦·µ»ي�ªȫȳʧ°ܶ�ȫȳ£¨³¬ʱ£©
     * @param{number} _frequency: ȫȳʧ°ܺ󹴶೤ʱ¼嗘тȫȳһ´̍
     * @param{number} _requestTimes: ȫȳʧ°ܺ�Ç숳¶ኙ´̍
     * @param{object} _frame: ´°ͥ¶Տ󣭐钪ҏ¸򀙖ƣ¬·򕲻┐¿ʄܳ�³Ħӑ¾­±»к»٣¬»ص�´ѐµŇꀶ
     */
    this.url = _url || "";
    this.successCallback = _successCallback || function(_xmlHttp, _params) {
        //iPanel.debug("[xmlHttp] responseText: " + _xmlHttp.responseText);
    };
    this.failureCallback = _failureCallback || function(_xmlHttp, _params) {
        //iPanel.debug("[xmlHttp] status: " + _xmlHttp.status + ", statusText: " + _xmlHttp.statusText);
    };
    this.urlParameters = _urlParameters || "";
    this.callbackParams = _callbackParams || null;
    this.async = typeof(_async) == "undefined" ? true : _async;
    this.charset = _charset || null;
    this.timeout = _timeout || 30000; //15s
    this.frequency = _frequency || 10000; //10s
    this.requestTimes = _requestTimes || 0;
    this.frame = _frame || window;

    this.timer = -1;
    this.counter = 0;

    this.method = "GET";
    this.headers = null;
    this.username = "";
    this.password = "";

    this.checkTimeout = 500;
    this.checkTimer = -1;
    this.checkCount = -1;

    this.createXmlHttpRequest = function() {
        var xmlHttp = null;
        try { //Standard
            xmlHttp = new XMLHttpRequest();
        } catch (exception) { //Internet Explorer
            try {
                xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (exception) {
                try {
                    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (exception) {
                    return false;
                }
            }
        }
        return xmlHttp;
    };

    this.xmlHttp = this.createXmlHttpRequest();

    this.requestData = function(_method, _headers, _username, _password) {
        /**
         * @param{string} _method: ´«µފ�½ʽ£¬POST/GET
         * @param{string} _headers: ´«µފ�·хϢ£¬json¸򊻍
         * @param{string} _username: ·�钪ɏ֤ʱµœû§Ļ
         * @param{string} _password: ·�钪ɏ֤ʱµœû§Ĝë
         */
        this.xmlHttp = this.createXmlHttpRequest();
        this.frame.clearTimeout(this.timer);
        this.method = typeof(_method) == "undefined" ? "GET" : (_method.toLowerCase() == "post") ? "POST" : "GET";
        this.headers = typeof(_headers) == "undefined" ? null : _headers;
        this.username = typeof(_username) == "undefined" ? "" : _username;
        this.password = typeof(_password) == "undefined" ? "" : _password;

        var target = this;
        this.xmlHttp.onreadystatechange = function() {
            target.stateChanged();
        };
        if (this.method == "POST") { //encodeURIComponent
            var url = encodeURI(this.url);
            var data = this.urlParameters;
        } else {
            //var url = encodeURI(this.url + (((this.urlParameters != "" && this.urlParameters.indexOf("?") == -1) && this.url.indexOf("?") == -1) ? ("?" + this.urlParameters) : this.urlParameters));
            var url = encodeURI(encodeURI(this.url));
            //iPanel.debug("[xm] xmlHttp get url00="+url);
            var data = null;
        }
        if (this.username != "") {
            this.xmlHttp.open(this.method, url, this.async, this.username, this.password);
        } else {
            this.xmlHttp.open(this.method, url, this.async);
        }
        var contentType = false;
        if (this.headers != null) {
            for (var key in this.headers) {
                if (key.toLowerCase() == "content-type") {
                    contentType = true;
                }
                this.xmlHttp.setRequestHeader(key, this.headers[key]);
            }
        }
        if (!contentType) {
            this.xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        }
        if (this.charset != null) { //ҪʹԃresponseXML¾Ͳ»Ŝʨ׃´̊�
            this.xmlHttp.overrideMimeType("text/html; charset=" + this.charset);
        }
        //iPanel.debug("[xmlHttp] requestData " + this.method + " url: " + url + ", data: " + data);
        this.xmlHttp.send(data);
        this.checkReadyState();
        this.timer = this.frame.setTimeout(function() {
            target.checkStatus();
        }, this.timeout);
    };
    this.checkReadyState = function() {
        var target = this;
        this.frame.clearTimeout(this.checkTimer);
        this.checkTimer = this.frame.setTimeout(function() {
            //iPanel.debug("global checkReadyState target.xmlHttp.readyState="+target.xmlHttp.readyState);
            //iPanel.debug("global checkReadyState target.xmlHttp.status="+target.xmlHttp.status);
            if (target.xmlHttp.readyState == 4 && (target.xmlHttp.status == 200 || target.xmlHttp.status == 204 || target.xmlHttp.status == 0)) {
                target.stateChanged();
            } else {
                target.checkCount++;
                if ((target.checkCount * target.checkTimeout) >= target.timeout) {
                    target.checkStatus();
                } else {
                    target.checkReadyState();
                }
            }
        }, this.checkTimeout);
    };
    this.stateChanged = function() { //״̬´¦m
        //iPanel.debug("[xmlHttp] readyState=" + this.xmlHttp.readyState);
        if (this.xmlHttp.readyState < 2) {

        } else {
            //iPanel.debug("[xmlHttp] readyState=" + this.xmlHttp.readyState + ", status=" + this.xmlHttp.status);
        }

        var target = this;
        if (this.xmlHttp.readyState == 2) {
            /*this.timer = this.frame.setTimeout(function() {
            		target.checkStatus();
            	}, this.timeout); */
        } else if (this.xmlHttp.readyState == 3) {
            if (this.xmlHttp.status == 401) {
                //iPanel.debug("[xmlHttp] Authentication, need correct username and pasword");
            }
        } else if (this.xmlHttp.readyState == 4) {
            this.frame.clearTimeout(this.timer);
            this.frame.clearTimeout(this.checkTimer);
            if (this.xmlHttp.status == 200 || this.xmlHttp.status == 204 || this.xmlHttp.status == 0) {
                //iPanel.debug("[xmlHttp] this.xmlHttp.resposeText=" + this.xmlHttp.responseText);
                this.success();
            }
            /*else if(this.xmlHttp.status == 0){
            	iPanel.debug("global_stateChanged_this.xmlHttp.status==0--һ°䎪0µŗ´̬ˇ¿は·¢µ¢);
            }*/
            else {
                //iPanel.debug("global_stateChanged_this.xmlHttp.status=="+this.xmlHttp.status);
                this.failed();
            }
        }
    };
    this.success = function() {
        this.checkCount = -1;
        this.frame.clearTimeout(this.checkTimer);
        if (this.callbackParams == null) {
            this.successCallback(this.xmlHttp);
        } else {
            this.successCallback(this.xmlHttp, this.callbackParams);
        }
        this.counter = 0;
    };
    this.failed = function() {
        this.checkCount = -1;
        this.frame.clearTimeout(this.checkTimer);
        if (this.callbackParams == null) {
            this.failureCallback(this.xmlHttp);
        } else {
            this.failureCallback(this.xmlHttp, this.callbackParams);
        }
        this.counter = 0;
    };
    this.checkStatus = function() { //³¬ʱ´¦m£¬ָ¶¨ʱ¼党ûԐ³ɹ¦·µ»ِƏ¢°´֕ʧ°ܴ¦m
        if (this.xmlHttp.readyState != 4) {
            if (this.counter < this.requestTimes) {
                this.requestAgain();
            } else {
                this.failed();
                this.requestAbort();
            }
        }
    };
    this.requestAgain = function() {
        this.requestAbort();
        var target = this;
        this.frame.clearTimeout(this.timer);
        this.timer = this.frame.setTimeout(function() {
            target.counter++;
            target.requestData(target.method, target.headers, target.username, target.password);
        }, this.frequency);
    };
    this.requestAbort = function() {
        this.checkCount = -1;
        this.frame.clearTimeout(this.timer);
        this.frame.clearTimeout(this.checkTimer);
        //iPanel.debug("[xmlHttp] call abort typeof this.xmlHttp="+typeof this.xmlHttp);
        //iPanel.debug("[xmlHttp] call abort typeof this.xmlHttp.abort="+typeof this.xmlHttp.abort);
        //abort()·½·¨¿ʒՍ£ֹһ¸�HttpRequest¶Տ󷓈TTPµŇ숳£¬°ѸöՏ󼖸´µ½³�´̬
        this.xmlHttp.abort();
    };
    this.addParameter = function(_json) {
        /**
         * @param{object} _json: ´«µݵĲϊ�¦m£¬ֻ֧³ժson¸򊻍
         */
        var url = this.url;
        var str = this.urlParameters;
        for (var key in _json) {
            if (url.indexOf("?") != -1) {
                url = "";
                if (str == "") {
                    str = "&" + key + "=" + _json[key];
                } else {
                    str += "&" + key + "=" + _json[key];
                }
                continue;
            }
            if (str == "") {
                str += "?";
            } else {
                str += "&";
            }
            str += key + "=" + _json[key];
        }
        this.urlParameters = str;
        return str;
    };
    this.getResponseXML = function() { //reponseXML of AJAX is null when response header 'Content-Type' is not include string 'xml', not like 'text/xml', 'application/xml' or 'application/xhtml+xml'
        if (this.xmlHttp.responseXML != null) {
            return this.xmlHttp.responseXML;
        } else if (this.xmlHttp.responseText.indexOf("<?xml") != -1) {
            return typeof(DOMParser) == "function" ? (new DOMParser()).parseFromString(this.xmlHttp.responseText, "text/xml") : (new ActivexObject("MSXML2.DOMDocument")).loadXML(this.xmlHttp.responseText);
        }
        return null;
    };
}
function setGlobalParms(kvJsonObj) {
    if (navigator.appName.indexOf("iPanel") != -1) {
        for (var key in kvJsonObj) {
            iPanel.setGlobalVar(key + "", kvJsonObj[key] + "");
        }
        iPanel.misc.save();
    } else {
        for (var key in kvJsonObj) {
            sessionStorage.setItem(key, kvJsonObj[key]);
        }
    }
}

function getGlobalParms(key) {
    var value = "";
    if (navigator.appName.indexOf("iPanel") != -1) {
        value = iPanel.getGlobalVar(key + "");
    } else {
        var value = sessionStorage.getItem(key);
    }
    if ((typeof value) == "undefined" || value == null || value == "") return "";
    else return value;
}

function removeGlobalParms(keys) {
    if (typeof keys == "undefined" || keys.length <= 0) return;
    if (navigator.appName.indexOf("iPanel") != -1) {
        for (var i = 0, len = keys.length; i < len; i++) {
            iPanel.delGlobalVar(keys[i] + "");
        }
        iPanel.misc.save();
    } else {
        for (var i = 0, len = keys.length; i < len; i++) {
            sessionStorage.removeItem(keys[i] + "");
        }
    }
}