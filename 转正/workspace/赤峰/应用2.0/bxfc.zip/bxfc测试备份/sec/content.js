{
  "type_list": [{
    "desc": "",
    "id": 7616,
    "name": "品牌",
    "style": "{\"index\":14,\"itemBgColor\":\"#154fa3\",\"keyContentBgColor\":\"#2264c5\",\"keyFontColor\":\"#ffffff\",\"keyContentFontColor\":\"#ffffff\",\"keyFocusColor\":\"#000000\",\"keyFocusBgColor\":\"#FFB400\",\"keySelectColor\":\"#ffffff\",\"keySelectBgColor\":\"#4388ef\",\"keyBorderColor\":\"#265db7\",\"iconFont\":\"\",\"iconFontColor\":null,\"bgImage\":\"\"}",
    "poster_list": {
      "dir": "http://poster.slave.homed.me:13160/poster/column/7616/",
      "list": {
        "640x153": "640x153_1.jpg"
      }
    },
    "extend_content": "",
    "link_info": "",
    "origin_id": "0",
    "program_property": {
      "content_type": 1107,
      "filter_info": {
        "type": {
          "id": 0,
          "name": "内容类型"
        },
        "items": []
      }
    },
    "is_purchase": 1,
    "package_list": [],
    "children": [{
      "desc": "",
      "id": 25420,
      "name": "蓝迪乐园",
      "style": "",
      "poster_list": {
        "dir": "http://poster.slave.homed.me:13160/poster/column/25420/",
        "list": {
          "640x153": "640x153_1.jpg"
        }
      },
      "extend_content": "{\"bindAppID\":\"1090520740\"}",
      "link_info": "",
      "origin_id": "0",
      "program_property": {
        "content_type": 1107,
        "filter_info": {
          "type": {
            "id": 0,
            "name": "内容类型"
          },
          "items": []
        }
      },
      "is_purchase": 0,
      "package_list": [{
        "package_id": 471,
        "package_name": "品牌套餐-蓝迪乐园",
        "order_type": 0,
        "inherit_flag": 0,
        "status": 65002
      }]
    }, {
      "desc": "",
      "id": 25539,
      "name": "卓越语文",
      "style": "",
      "poster_list": {
        "dir": "http://poster.slave.homed.me:13160/poster/column/25539/",
        "list": {
          "640x153": "640x153_1.jpg"
        }
      },
      "extend_content": "{\"bindAppID\":\"1090519886\"}",
      "link_info": "",
      "origin_id": "0",
      "program_property": {
        "content_type": 1107,
        "filter_info": {
          "type": {
            "id": 0,
            "name": "内容类型"
          },
          "items": []
        }
      },
      "is_purchase": 0,
      "package_list": [{
        "package_id": 476,
        "package_name": "品牌套餐-卓越语文",
        "order_type": 0,
        "inherit_flag": 0,
        "status": 65005
      }]
    }, {
      "desc": "",
      "id": 25545,
      "name": "德智教育",
      "style": "",
      "poster_list": {
        "dir": "http://poster.slave.homed.me:13160/poster/column/25545/",
        "list": {
          "640x153": "640x153_1.jpg"
        }
      },
      "extend_content": "{'columnToProgram':'','bindAppID':1090519887}",
      "link_info": "",
      "origin_id": "0",
      "program_property": {
        "content_type": 1107,
        "filter_info": {
          "type": {
            "id": 0,
            "name": "内容类型"
          },
          "items": []
        }
      },
      "is_purchase": 1,
      "package_list": []
    }, {
      "desc": "节目在内容上包括知识的普及和思维的锻炼，又包括情感的培养和习惯的养成，适合2至6岁幼儿观看。",
      "id": 25562,
      "name": "凤凰学园",
      "style": "",
      "poster_list": {
        "dir": "http://poster.slave.homed.me:13160/poster/column/25562/",
        "list": {
          "640x153": "640x153_1.jpg"
        }
      },
      "extend_content": "{\"bindAppID\":\"1090520738\"}",
      "link_info": "",
      "origin_id": "0",
      "program_property": {
        "content_type": 1107,
        "filter_info": {
          "type": {
            "id": 0,
            "name": "内容类型"
          },
          "items": []
        }
      },
      "is_purchase": 0,
      "package_list": [{
        "package_id": 472,
        "package_name": "品牌套餐-凤凰学园",
        "order_type": 0,
        "inherit_flag": 0,
        "status": 65005
      }]
    }, {
      "desc": "",
      "id": 25583,
      "name": "尼克学堂",
      "style": "",
      "poster_list": {
        "dir": "http://poster.slave.homed.me:13160/poster/column/25583/",
        "list": {
          "640x153": "640x153_1.jpg"
        }
      },
      "extend_content": "{\"bindAppID\":\"1090520741\"}",
      "link_info": "",
      "origin_id": "0",
      "program_property": {
        "content_type": 1107,
        "filter_info": {
          "type": {
            "id": 0,
            "name": "内容类型"
          },
          "items": []
        }
      },
      "is_purchase": 0,
      "package_list": [{
        "package_id": 473,
        "package_name": "品牌套餐-尼克学堂",
        "order_type": 0,
        "inherit_flag": 0,
        "status": 65005
      }]
    }]
  }],
  "ret": 0,
  "request_id": "59f192bfc0a8236d00007b782142c4cc",
  "ret_msg": "success"
}