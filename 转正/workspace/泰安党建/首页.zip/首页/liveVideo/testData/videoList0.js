{
	"result":"E0000",
	"msg":[{
			"secondMeeting":[{
					"startDate":"2016-06-18 10:30:00",
					"meetingName":"ѧϰϰ��ϯ����2",
					"videoId":"2",
					"endDate":"",
					"placeMaster":"0002"
				}],
				"mainMeeting":{
					"startDate":"2016-06-18 10:00:00",
					"meetingName":"ѧϰϰ��ϯ����1",
					"videoId":"1",
					"endDate":"",
					"placeMaster":"0001"
				},
				"ownMeeting":{
					"startDate":"2016-06-18 10:00:00",
					"meetingName":"ѧϰϰ��ϯ����1",
					"videoId":"1",
					"endDate":"",
					"placeMaster":"0001"
				}
	},{
		"secondMeeting":[{
					"startDate":"2016-06-18 10:30:00",
					"meetingName":"ѧϰϰ��ϯ����2",
					"videoId":"2",
					"endDate":"",
					"placeMaster":"0002"
				}],
				"mainMeeting":{
					"startDate":"2016-06-19 11:00:00",
					"meetingName":"ѧϰϰ��ϯ����2",
					"videoId":"1",
					"endDate":"",
					"placeMaster":"0001"
				},
				"ownMeeting":{
					"startDate":"2016-06-18 10:00:00",
					"meetingName":"ѧϰϰ��ϯ����1",
					"videoId":"1",
					"endDate":"",
					"placeMaster":"0001"
				}
	}]
}