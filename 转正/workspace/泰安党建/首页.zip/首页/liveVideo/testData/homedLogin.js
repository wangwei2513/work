﻿{
   
	"access_token" : "TZQ7FA1GOX79YYADH180ARR3TMFSSE2BNK50001005W18132",
   
	"area_code" : "",
   
	"default_play_mode" : "IP",
   
	"device_id" : 100,
   
	"home_id" : 96,
   
	"icon_url" : {
      
	"140x140" : "http://apps.homed.tv/sys_img/role/user0.jpg"
   
},
   
"is_first_login" : 0,
   
"is_super_user" : 1,
  
 "message" : "success",
  
 "nick_name" : "锦绣社区党支部",
   
"portal_id" : 1,
   
"portal_url" : "http://webclient.homed.me/application/homedPortal/index.php",
   
"property" : 0,
   
"ret" : 0,
   
"ret_msg" : "success",
   
"style_id" : 1,
   
"user_id" : 50001005,
   
"user_name" : "zz8538002343236584"

}