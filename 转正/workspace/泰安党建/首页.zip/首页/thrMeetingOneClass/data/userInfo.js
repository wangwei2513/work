{
   "alternative_user_name" : "denglc",
   "bind_user_id" : 0,
   "bind_user_name" : "",
   "home_id" : 300371,
   "home_name" : "������",
   "home_status" : 2,
   "max_user_num" : 90,
   "message" : "",
   "ret" : 0,
   "ret_msg" : "success",
   "user_list" : [
      {
         "color_id" : 0,
         "font_id" : 0,
         "format_id" : 0,
         "icon_url" : {
            "140x140" : "http://apps.homed.me/sys_img/role/user0.jpg"
         },
         "is_super_user" : 1,
         "nick_name" : "������",
         "portal_name" : "�Ῠportal",
         "show_name" : 2,
         "style_id" : 1,
         "style_name" : "",
         "user_id" : 50300589,
         "user_name" : "denglc"
      }
   ]
}