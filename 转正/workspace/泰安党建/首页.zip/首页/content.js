[
  {
    'albumImageUrls': [],
    'author': '',
    'content': '',
    'date': '',
    'description': '',
    'entryImageUrl': 'http://10.191.85.208:80/appcmsFiles/1500275078605734089.jpg',
    'id': 12371,
    'linkUrl': '',
    'subTitle': '',
    'title': '�����ݳ�',
    'videoUrl': 'http://192.168.18.66:3080/appcms3.0//demo/demo.mp4'
  }
]
