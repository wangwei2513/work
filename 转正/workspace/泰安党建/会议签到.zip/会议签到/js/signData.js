{
    "result": "E0000",
    "msg": [
        {
            "identifyValue":"287",
            "placeName":"��Ʒ��������1",
            "placeMaster":"zhibu",
            "deptId":"",
            "devSN":"",
            "signInfo":[{
                "signTime": "2017-01-01 10:08:00",
                "pin": "1",
                "status": 1,
                "personName": "aaa"
            },
            {
                "signTime": "2017-01-01 09:52:00",
                "pin": "2",
                "status": 0,
                "personName": "bbb"
            },
            {
                "signTime": "2017-01-01 09:55:00",
                "pin": "4",
                "status": 0,
                "personName": "ccc"
            },{
                "signTime": "2017-01-01 10:08:00",
                "pin": "1",
                "status": 1,
                "personName": "ddd"
            },
            {
                "signTime": "2017-01-01 09:52:00",
                "pin": "2",
                "status": 0,
                "personName": "eee"
            },
            {
                "signTime": "2017-01-01 09:55:00",
                "pin": "4",
                "status": 2,
                "personName": "fff"
            },{
                "signTime": "2017-01-01 10:08:00",
                "pin": "1",
                "status": 1,
                "personName": "ggg"
            },
            {
                "signTime": "2017-01-01 09:52:00",
                "pin": "2",
                "status": 0,
                "personName": "hhh"
            },
            {
                "signTime": "2017-01-01 09:55:00",
                "pin": "4",
                "status": 0,
                "personName": "iii"
            }]
        },{
            "identifyValue":"287",
            "placeName":"�����з�����1",
            "placeMaster":"",
            "deptId":"",
            "devSN":"",
            "signInfo":[{
                "signTime": "2017-01-01 10:08:00",
                "pin": "1",
                "status": 2,
                "personName": "ddd"
            },
            {
                "signTime": "2017-01-01 09:52:00",
                "pin": "2",
                "status": 0,
                "personName": "eee"
            },
            {
                "signTime": "2017-01-01 09:55:00",
                "pin": "4",
                "status": 0,
                "personName": "fff"
            }]
        },{
            "identifyValue":"287",
            "placeName":"ְ�ܹ�������1",
            "placeMaster":"",
            "deptId":"",
            "devSN":"",
            "signInfo":[{
                "signTime": "2017-01-01 10:08:00",
                "pin": "1",
                "status": 1,
                "personName": "ggg"
            },
            {
                "signTime": "2017-01-01 09:52:00",
                "pin": "2",
                "status": 0,
                "personName": "hhh"
            },
            {
                "signTime": "2017-01-01 09:55:00",
                "pin": "4",
                "status": 2,
                "personName": "iii"
            }]
        }
        
    ]
}