{
   "access_token" : "R59F16019U109A6023K3BA04088I550FA8C0P8M2FF86ADWDB964B9D091",
   "area_code" : "",
   "default_play_mode" : [
      {
         "mode" : 1,
         "platform" : 1,
         "type" : 1
      },
      {
         "mode" : 2,
         "platform" : 1,
         "type" : 2
      },
      {
         "mode" : 2,
         "platform" : 1,
         "type" : 3
      },
      {
         "mode" : 2,
         "platform" : 1,
         "type" : 4
      },
      {
         "mode" : 2,
         "platform" : 1,
         "type" : 5
      },
      {
         "mode" : 1,
         "platform" : 2,
         "type" : 1
      },
      {
         "mode" : 2,
         "platform" : 2,
         "type" : 2
      },
      {
         "mode" : 1,
         "platform" : 2,
         "type" : 3
      },
      {
         "mode" : 1,
         "platform" : 2,
         "type" : 4
      },
      {
         "mode" : 2,
         "platform" : 2,
         "type" : 5
      }
   ],
   "device_id" : 1000358024,
   "extend" : {
      "departmentcolumn" : {
         "mobile" : 0,
         "stb" : 32563
      },
      "departmentid" : "0",
      "departmentname" : "Ӧ�ÿ�������",
      "isadministration" : 0,
      "issport" : 1
   },
   "home_id" : 300371,
   "icon_url" : {
      "140x140" : "http://apps.homed.me/sys_img/role/user0.jpg"
   },
   "is_first_login" : 0,
   "is_super_user" : 1,
   "is_update_pwd" : 1,
   "last_logged_ip" : "192.168.15.85",
   "last_logged_time" : 1509083166,
   "message" : "success",
   "nick_name" : "������",
   "portal_id" : 28,
   "portal_url" : "http://webclient.homed.me/application/homedPortal/index.php?bsID=10",
   "property" : 0,
   "ret" : 0,
   "ret_msg" : "success",
   "style_id" : 1,
   "user_id" : 50300589,
   "user_name" : "denglc"
}