{
  "blurImageUrl": "",
  "clickable": 1,
  "enName": "sub_act",
  "entryWord": "",
  "focusImageUrl": "",
  "isManaged": "managed",
  "linkUrl": "",
  "listType": "list",
  "name": "",
  "navigator": "",
  "newAdd": 0,
  "nodePath": "//"
}