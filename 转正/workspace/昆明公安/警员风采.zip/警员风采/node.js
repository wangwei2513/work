{
  "blurImageUrl": "",
  "clickable": 1,
  "enName": "sub_act",
  "entryWord": "",
  "focusImageUrl": "",
  "isManaged": "managed",
  "linkUrl": "",
  "listType": "list",
  "name": "��Ա���",
  "navigator": "��Ա���",
  "newAdd": 0,
  "nodePath": "//"
}